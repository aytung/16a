from mic import SoundRecorder
mic = SoundRecorder()
mic.open_stream()